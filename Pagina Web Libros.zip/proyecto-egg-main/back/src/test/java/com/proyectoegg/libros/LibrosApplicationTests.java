package com.proyectoegg.libros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
