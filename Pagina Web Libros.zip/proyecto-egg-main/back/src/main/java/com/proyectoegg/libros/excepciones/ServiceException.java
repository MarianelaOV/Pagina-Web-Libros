package com.proyectoegg.libros.excepciones;

public class ServiceException extends Exception {


    public ServiceException() {
    }

    public ServiceException(String msg) {
        super(msg);
    }
}
