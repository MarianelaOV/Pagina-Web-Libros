package com.proyectoegg.libros.entidades;

public class Aviso {

    private Usuario usuario;

    
}
